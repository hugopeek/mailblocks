<?php
/**
 * mbLexiconManager
 *
 * Load MailBlocks lexicon in MODX manager.
 *
 * @var modX $modx
 * @package mailblocks
 */

$modx->controller->addLexiconTopic('mailblocks:default');